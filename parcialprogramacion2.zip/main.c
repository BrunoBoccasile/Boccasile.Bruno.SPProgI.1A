//BRUNO BOCCASILE | recuperatorio 2do parcial programacion
#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    int id;
    char marca[20];
    int tipo;
    float peso;
}eVehiculo;

eVehiculo* newVehiculo();
eVehiculo* newVehiculoParam(int id, char* marca, int tipo, float peso);
int vehiculoSetId(eVehiculo* vehiculo, int id);
int vehiculoSetId(eVehiculo* vehiculo, int id);

int vehiculoSetMarca(eVehiculo* vehiculo, char* marca);

int vehiculoSetTipo(eVehiculo* vehiculo, int tipo);
int vehiculoSetPeso(eVehiculo* vehiculo, float peso);

int vehiculoGetId(eVehiculo* vehiculo, int* pId);
int vehiculoGetMarca(eVehiculo* vehiculo, char* pMarca);
int vehiculoGetTipo(eVehiculo* vehiculo, int* pTipo);

int vehiculoGetPeso(eVehiculo* vehiculo, float* pPeso);


int main()
{
    eVehiculo* vehiculo;
    FILE* f;
    int idAux;
    char marcaAux[20];
    int tipoAux;
    float pesoAux;

    vehiculo = newVehiculoParam(1, "Fiat", 3, 3000);

    f = fopen("vehiculo.txt", "w");

    vehiculoGetId(vehiculo, &idAux);

    vehiculoGetMarca(vehiculo, marcaAux);
    vehiculoGetTipo(vehiculo, &tipoAux);

    vehiculoGetPeso(vehiculo, &pesoAux);

    fprintf(f, "%d,%s,%d,%.2f", idAux, marcaAux, tipoAux, pesoAux);

    f = fopen("vehiculo.bin", "wb");

    fwrite(vehiculo, sizeof(eVehiculo), 1, f);





		fclose(f);
    return 0;
}


eVehiculo* newVehiculo()
{
    eVehiculo* nuevoVehiculo = (eVehiculo*) malloc(sizeof(eVehiculo));
    if(nuevoVehiculo != NULL)
    {
        nuevoVehiculo->id = 0;
        strcpy(nuevoVehiculo->marca, "");
        strcpy(nuevoVehiculo->tipo, "");
        nuevoVehiculo->peso = 0.0;
    }
    return nuevoVehiculo;

}

eVehiculo* newVehiculoParam(int id, char* marca, int tipo, float peso)
{
    eVehiculo* nuevoVehiculo = newVehiculo();
    if(nuevoVehiculo!= NULL )
    {
        if(  !(vehiculoSetId(nuevoVehiculo, id) &&
               vehiculoSetMarca(nuevoVehiculo, marca) &&
               vehiculoSetTipo(nuevoVehiculo, tipo) &&
               vehiculoSetPeso(nuevoVehiculo, peso))   )
        {
             free(nuevoVehiculo);
            nuevoVehiculo = NULL;
        }

    }

  return nuevoVehiculo;
}

int vehiculoSetId(eVehiculo* vehiculo, int id)
{
    int todoOk = 0;
    if(vehiculo != NULL && id >= 0)
    {
        vehiculo->id = id;
        todoOk = 1;
    }
    return todoOk;
}

int vehiculoSetMarca(eVehiculo* vehiculo, char* marca)
{
    int todoOk = 0;
    if(vehiculo != NULL && marca != NULL && (strlen(marca)>0 && strlen(marca) < 20))
    {
        strcpy(vehiculo->marca, marca);
        todoOk = 1;
    }
    return todoOk;
}

int vehiculoSetTipo(eVehiculo* vehiculo, int tipo)
{
    int todoOk = 0;
    if(vehiculo != NULL && tipo >= 0)
    {
        vehiculo->tipo = tipo;
        todoOk = 1;
    }
    return todoOk;
}

int vehiculoSetPeso(eVehiculo* vehiculo, float peso)
{
    int todoOk = 0;
    if(vehiculo != NULL && peso > 0.0)
    {
        vehiculo->peso = peso;
        todoOk = 1;
    }
    return todoOk;
}

int vehiculoGetId(eVehiculo* vehiculo, int* pId)
{
    int todoOk = 0;
    if(vehiculo != NULL && pId != NULL)
    {
        *pId = vehiculo->id;

        todoOk = 1;
    }

    return todoOk;
}

int vehiculoGetMarca(eVehiculo* vehiculo, char* pMarca)
{
    int todoOk = 0;

    if(vehiculo != NULL && pMarca != NULL)
    {
        strcpy(pMarca, vehiculo->marca);

        todoOk = 1;
    }

    return todoOk;
}

int vehiculoGetTipo(eVehiculo* vehiculo, int* pTipo)
{
    int todoOk = 0;
    if(vehiculo != NULL && pTipo != NULL)
    {
        *pTipo = vehiculo->tipo;

        todoOk = 1;
    }

    return todoOk;
}

int vehiculoGetPeso(eVehiculo* vehiculo, float* pPeso)
{
    int todoOk = 0;
    if(vehiculo != NULL && pPeso!= NULL)
    {
        *pPeso = vehiculo->peso;

        todoOk = 1;
    }

    return todoOk;
}
